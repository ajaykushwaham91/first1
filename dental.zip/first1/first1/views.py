from django.shortcuts import render
from .forms import FormContactForm
def index(request):
    return render(request,'index.html')

def home(request):
    return render(request,'home.html')

def about(request):
    return render(request,'about.html')

def services(request):
    return render(request,'services.html')

def gallery(request):
    return render(request,'gallery.html')

def blog(request):
    return render(request,'blog.html')

# def contact(request):
#     return render(request,'contact.html')
def showform(request):
    form = FormContactForm(request.POST or None)
    if form.is_valid():
        form.save()

    context = {'form': form}

    return render(request, 'contact.html', context)

def single(request):
    return render(request,'single.html')


    
