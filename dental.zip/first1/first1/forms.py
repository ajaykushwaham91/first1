from django import forms
from .models import Contact

class FormContactForm(forms.ModelForm):
    class Meta:
        model= Contact
        fields= ["name", "email", "contact", "message"]